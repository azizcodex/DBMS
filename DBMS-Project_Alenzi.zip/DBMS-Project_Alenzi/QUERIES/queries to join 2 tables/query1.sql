select Reviewer_Lname,Title
from Papers
inner join Reviewers
on Papers.Paper_ID = Reviewers.Reviewer_ID;
