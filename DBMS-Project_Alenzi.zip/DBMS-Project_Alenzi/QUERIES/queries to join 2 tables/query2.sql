select Author_Fname,Author_Lname, Title
from Papers
inner join Authors
on Papers.Paper_ID = Authors.Author_ID
where  Author_Fname = 'Peri';
