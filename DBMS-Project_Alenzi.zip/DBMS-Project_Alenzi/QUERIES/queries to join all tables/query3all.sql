select Chair_Fname, Venue_Type, Conf_Name, Country,Reviewer_Lname, Title
from ConferenceEvent
join Papers on ConferenceEvent.Paper_id = Papers.Paper_ID
join Venue on ConferenceEvent.Venue_id = Venue.Venue_ID
join Chair on ConferenceEvent.Chair_id = Chair.Chair_ID
join Reviewers on ConferenceEvent.Reviewer_id = Reviewers.Reviewer_ID
join Authors on  ConferenceEvent.Author_id = Authors.Author_ID
where  Capacity = 69;