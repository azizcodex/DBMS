.open d.db
ATTACH 'd2.db' as d2;

INSERT INTO d2.'ChairInfo'
SELECT Chair_ID, Chair_Fname, Chair_Lname, Birthday
FROM Chair;

INSERT INTO d2.'ChairMajor'
SELECT Chair_ID, Major
FROM Chair;

INSERT INTO d2.Venue
SELECT * FROM Venue;

INSERT INTO d2.ConferenceEvent
SELECT * FROM ConferenceEvent;

INSERT INTO d2.Authors
SELECT * FROM Authors;

INSERT INTO d2.Papers
SELECT * FROM Papers;

INSERT INTO d2.Reviewers
SELECT * FROM Reviewers;