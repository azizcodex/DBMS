.open d.db
ATTACH 'd3.db' as d3;

INSERT INTO d3.Chair
SELECT * FROM Chair;

INSERT INTO d3.'VenueInfo'
SELECT Venue_ID,Venue_Name, Venue_Type, Capacity 
FROM Venue;

INSERT INTO d3.'VenueLocation'
SELECT Venue_ID, Address
FROM Venue;

INSERT INTO d3.ConferenceEvent
SELECT * FROM ConferenceEvent;

INSERT INTO d3.Authors 
SELECT * FROM Authors;

INSERT INTO d3.Papers
SELECT * FROM Papers;

INSERT INTO d3.Reviewers
SELECT * FROM Reviewers;

